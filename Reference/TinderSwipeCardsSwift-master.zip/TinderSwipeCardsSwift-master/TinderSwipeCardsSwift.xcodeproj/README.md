TinderSwipeCardsSwift
======

### Credits to: https://github.com/cwRichardKim/TinderSimpleSwipeCards

Implement Tinder swipe cards effect in Swift.